package entrega;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class App 
{
    public static void main(String[] args)
    {
        String url = "jdbc:postgresql://localhost:5432/CONEXAO";
        String user = "postgres"; 
        String password = "1234"; 
        try {
            // No need to load the driver class explicitly
            Connection connection = DriverManager.getConnection(url, user, password);
            Statement statement = connection.createStatement();
            System.out.println("Connection is Successful to the database " + url);
            // Criar a tabela Pessoa
            String createTableSQL = "CREATE TABLE IF NOT EXISTS Pessoa ("
                    + "ID_PESSOA SERIAL PRIMARY KEY, "
                    + "NOME_PESSOA VARCHAR(50) NOT NULL)";
            statement.execute(createTableSQL);
            System.out.println("Tabela Pessoa criada com sucesso!");

            // Inserir um registro na tabela Pessoa
            String insertSQL = "INSERT INTO Pessoa (NOME_PESSOA) VALUES ('Bruna')";
            statement.executeUpdate(insertSQL);
            System.out.println("Registro inserido com sucesso na tabela Pessoa!");
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
}
